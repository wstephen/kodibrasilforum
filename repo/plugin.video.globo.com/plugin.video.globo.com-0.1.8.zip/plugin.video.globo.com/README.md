# Globo.com XBMC Plugin

Vídeos dos canais e serviços globo.com: [Globo.tv+][globotvplus] e [GlobosatPlay][globoplay].

[Globo.tv+][globotvplus] é um serviço para assinantes globo.com, que disponibiliza
conteúdos como jornais, novelas e séries produzidos pela Rede Globo de
televisão, na íntegra e sob demanda.

[GlobosatPlay][globoplay] é um serviço de vídeos sob demanda oferecidos para assinantes
de TV a Cabo das operadoras Algar Telecom, GVT, Multiplay, NET, NET Angra, Tv
Oi, Sky e Vivo. Oferece conteúdos sob demanda dos canais +Globosat, Bis, Canal
Brasil, Globonews, Canal Off, Sportv, Combate, Gloob, GNT, Multishow, Megapix e
Telecine Play. E streaming ao vivo dos canais Globonews, Sportv, Sportv 2,
Sportv 3, Combate, Premiere.

Nota: este plugin ainda está em desenvolvimento, com vários canais e
fornecedores de autenticação ainda não funcionais. Note também que mesmo se
funcionais, acesso ao conteúdo é dependente de um pacote de assinatura
correspondente (como Combate, Premiere e Telecine Play). Por favor, relate os
devidos problemas caso os encontre.

Compre uma cerveja para o desenvolvedor pelo [paypal][paypalVitorHirota].

Thread de discussão oficial em [forum.kodi.tv][kodiGlobo].

*Videos from channels and services from globo.com: Globo+ and GlobosatPlay.*

*Buy a beer for the developer at [paypal][paypalVitorHirota].*

*Official discussion thread at [forum.kodi.tv][kodiGlobo].*
