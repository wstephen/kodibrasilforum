Version 3.6.8 - fix for HD

Version 3.6.7 - fix for when "h264" not present

Version 3.6.6 - dzebrys fix for video title 11-23-14

Version 3.6.4 - Fully patched as of July 20 2014