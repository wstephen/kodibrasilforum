# Globo.tv XBMC Plugin

Veja os vídeos disponibilizados gratuitamente pelo site http://globotv.globo.com

Inclui vídeos dos canais Globo, GNT, Multishow, Sportv, Globo News, Canal Brasil, entre outros.

Para alterações, verifique o [changelog](https://bitbucket.org/vitorhirota/repository.brazilian.xbmc-addons/src/188e0261e8570d0a643914f056362698a851f781/plugin.video.globotv/changelog.txt?at=master).

Para instalação, verifique o [README](https://bitbucket.org/vitorhirota/repository.brazilian.xbmc-addons) principal.

---

Watch Globo TV videos freely available online.

For changes, check the [changelog](https://bitbucket.org/vitorhirota/repository.brazilian.xbmc-addons/src/188e0261e8570d0a643914f056362698a851f781/plugin.video.globotv/changelog.txt?at=master).

For instalation, check main [README](https://bitbucket.org/vitorhirota/repository.brazilian.xbmc-addons).
