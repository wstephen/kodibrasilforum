# plugin.video.kordkutters
A kodi plugin dedicated to kordkutters podcast.

![](http://s16.postimg.org/6dews44lx/image.png)

Ned and Nate are two members of Team Kodi. Ned is primarily responsible for the Kodi Wiki. Nate is the Foundation president and does various jobs related to project and community management for the group. They decided to put together the KordKutters project because, frankly, they didn’t have much to do one week, and it seemed like it could be fun. They’ve been showing off Kodi for years at conventions and expos, so why not start doing videos with the exact same idea in mind?
