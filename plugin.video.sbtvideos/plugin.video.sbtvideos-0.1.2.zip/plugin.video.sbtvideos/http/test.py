class Test:
	foo = 1;
	boo = "test";
	
	def __init__(self):
		self.foo = self.foo + 1;
		
test = Test();