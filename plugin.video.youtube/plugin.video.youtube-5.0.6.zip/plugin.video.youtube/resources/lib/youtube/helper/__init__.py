__author__ = 'bromix'

from resource_manager import ResourceManager
